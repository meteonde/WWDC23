#  Recommendations.

Hello! for a better experience using this Swift playground, I strongly recommend using an iPad Pro 12.9. Thank you!

